import { Loader2 } from "lucide-react";

export function UploadProgress({
  progress,
  label = "Đang upload file...",
}: {
  progress?: number | null;
  label?: string;
}) {
  const hasProgress = typeof progress === "number" && progress >= 0;
  const safeProgress = hasProgress
    ? Math.min(100, Math.max(0, progress || 0))
    : 0;

  return (
    <div className="rounded-2xl border border-line bg-surface px-4 py-3">
      <div className="flex items-center justify-between gap-3 text-xs font-semibold text-neutralText">
        <span className="inline-flex min-w-0 items-center gap-2">
          <Loader2 className="h-4 w-4 shrink-0 animate-spin text-moss" />
          <span className="truncate">{label}</span>
        </span>
        {hasProgress ? (
          <span className="shrink-0 text-moss">{safeProgress}%</span>
        ) : null}
      </div>
      <div className="mt-3 h-2 overflow-hidden rounded-full bg-primarySoft">
        <div
          className={
            hasProgress
              ? "h-full rounded-full bg-moss transition-all"
              : "h-full w-1/2 animate-pulse rounded-full bg-moss"
          }
          style={hasProgress ? { width: `${safeProgress}%` } : undefined}
        />
      </div>
    </div>
  );
}
