"use client";

import { Headphones, Music2 } from "lucide-react";

import { Badge } from "@/components/common/Badge";
import { Card, CardContent, CardHeader } from "@/components/common/Card";
import type { ListeningSet } from "@/types";

type Props = {
  listeningSet: ListeningSet;
};

export function ListeningAudioPanel({ listeningSet }: Props) {
  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
          <div>
            <p className="text-xs font-bold uppercase tracking-[.22em] text-sage">
              Audio panel
            </p>
            <h2 className="mt-1 font-serif text-2xl font-bold text-ink">
              Audio & Transcript
            </h2>
            <p className="mt-1 text-sm leading-6 text-neutralText">
              Kiểm tra file nghe và transcript trước khi xuất bản Listening Set.
            </p>
          </div>

          {listeningSet.audioUrl ? (
            <Badge tone="success">Có audio</Badge>
          ) : (
            <Badge tone="warning">Chưa có audio</Badge>
          )}
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="rounded-2xl border border-line bg-paper p-5">
          <div className="flex items-start gap-3">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl border border-line bg-cream">
              <Headphones className="h-5 w-5 text-moss" />
            </div>

            <div className="min-w-0 flex-1">
              <p className="font-semibold text-ink">{listeningSet.title}</p>

              <div className="mt-2 flex flex-wrap gap-2">
                {listeningSet.level ? (
                  <Badge tone="brown">Band {listeningSet.level}</Badge>
                ) : null}

                {listeningSet.audioSource ? (
                  <Badge tone="sage">{String(listeningSet.audioSource)}</Badge>
                ) : null}

                <Badge
                  tone={
                    listeningSet.status === "PUBLISHED" ? "success" : "warning"
                  }
                >
                  {listeningSet.status || "DRAFT"}
                </Badge>
              </div>

              {listeningSet.audioUrl ? (
                <>
                  <audio controls className="mt-4 w-full">
                    <source src={listeningSet.audioUrl} />
                    Trình duyệt của bạn không hỗ trợ audio.
                  </audio>

                  <p className="mt-3 break-all font-mono text-xs text-neutralText">
                    {listeningSet.audioUrl}
                  </p>
                </>
              ) : (
                <div className="mt-4 rounded-2xl border border-dashed border-line bg-cream/60 p-4 text-sm leading-6 text-warning">
                  Chưa có audio URL. Hãy nhập audio URL trong form thông tin bài
                  nghe trước khi xuất bản.
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="rounded-2xl border border-line bg-paper p-5">
          <div className="flex items-center gap-2">
            <Music2 className="h-4 w-4 text-moss" />
            <p className="font-serif text-xl font-bold text-ink">Transcript</p>
          </div>

          {listeningSet.transcriptText ? (
            <p className="mt-4 max-h-[360px] overflow-auto whitespace-pre-line rounded-2xl border border-line bg-cream/60 p-4 text-sm leading-7 text-ink">
              {listeningSet.transcriptText}
            </p>
          ) : (
            <div className="mt-4 rounded-2xl border border-dashed border-line bg-cream/60 p-4 text-sm leading-6 text-neutralText">
              Chưa có transcript. Transcript không bắt buộc, nhưng nên có để
              giáo viên/admin dễ kiểm tra nội dung nghe.
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
