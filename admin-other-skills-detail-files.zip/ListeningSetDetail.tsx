"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { ArrowLeft, Headphones, RefreshCw, Send } from "lucide-react";

import { Badge } from "@/components/common/Badge";
import { Button } from "@/components/common/Button";
import { Card, CardContent, CardHeader } from "@/components/common/Card";
import { PageHeader } from "@/components/common/PageHeader";
import {
  EmptyState,
  ErrorState,
  LoadingState,
} from "@/components/common/States";
import { ListeningSetForm } from "@/components/content-bank/listening/ListeningSetForm";
import { ListeningQuestionManager } from "@/components/content-bank/listening/ListeningQuestionManager";
import {
  getAdminListening,
  publishListening,
  unpublishListening,
} from "@/lib/api/listening.api";
import { getErrorMessage } from "@/lib/api/client";
import type { ListeningSet, PublishStatus } from "@/types";

type Props = {
  setId: string;
};

function statusTone(status?: PublishStatus) {
  if (status === "PUBLISHED") return "success";
  if (status === "ARCHIVED") return "danger";
  return "warning";
}

export function ListeningSetDetail({ setId }: Props) {
  const [listeningSet, setListeningSet] = useState<ListeningSet | null>(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [error, setError] = useState("");

  const loadData = useCallback(async () => {
    setLoading(true);
    setError("");

    try {
      const data = await getAdminListening(setId);
      setListeningSet(data);
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [setId]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleTogglePublish = async () => {
    if (!listeningSet) return;

    setActionLoading(true);
    setError("");

    try {
      if (listeningSet.status === "PUBLISHED") {
        await unpublishListening(listeningSet.id);
      } else {
        await publishListening(listeningSet.id);
      }

      await loadData();
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setActionLoading(false);
    }
  };

  if (loading) return <LoadingState label="Đang tải Listening Set..." />;

  if (error && !listeningSet) {
    return <ErrorState message={error} onRetry={loadData} />;
  }

  if (!listeningSet) {
    return (
      <EmptyState
        title="Không tìm thấy Listening Set"
        description="Bài nghe có thể đã bị xóa hoặc ID không hợp lệ."
        action={
          <Link href="/admin/listening-sets">
            <Button variant="outline">Quay lại ngân hàng Listening</Button>
          </Link>
        }
      />
    );
  }

  const isPublished = listeningSet.status === "PUBLISHED";
  const questionCount = listeningSet.questions?.length || 0;
  const canPublish = Boolean(listeningSet.audioUrl && questionCount > 0);

  return (
    <div>
      <PageHeader
        eyebrow="Admin / Listening Bank"
        title={listeningSet.title}
        description="Quản lý audio, transcript, câu hỏi, đáp án và trạng thái xuất bản của Listening Set."
        actions={
          <>
            <Link href="/admin/listening-sets">
              <Button variant="outline">
                <ArrowLeft className="h-4 w-4" />
                Quay lại
              </Button>
            </Link>

            <Button
              variant="outline"
              onClick={loadData}
              disabled={actionLoading}
            >
              <RefreshCw className="h-4 w-4" />
              Làm mới
            </Button>

            <Button
              onClick={handleTogglePublish}
              disabled={actionLoading || (!isPublished && !canPublish)}
              variant={isPublished ? "secondary" : "primary"}
            >
              <Send className="h-4 w-4" />
              {isPublished ? "Gỡ xuất bản" : "Xuất bản"}
            </Button>
          </>
        }
      />

      <div className="grid gap-5 xl:grid-cols-[1fr_360px]">
        <main className="space-y-5">
          {error ? <ErrorState message={error} onRetry={loadData} /> : null}

          <ListeningSetForm
            mode="edit"
            initialData={listeningSet}
            onSaved={setListeningSet}
          />

          <ListeningQuestionManager
            listeningSetId={listeningSet.id}
            questions={listeningSet.questions || []}
            isPublished={isPublished}
            onChanged={loadData}
          />
        </main>

        <aside className="space-y-4">
          <Card>
            <CardHeader>
              <p className="text-xs font-bold uppercase tracking-[.22em] text-sage">
                Listening overview
              </p>
              <h2 className="mt-1 font-serif text-xl font-bold text-ink">
                Thông tin bài nghe
              </h2>
            </CardHeader>

            <CardContent className="space-y-4">
              <div className="flex flex-wrap gap-2">
                <Badge tone={statusTone(listeningSet.status)}>
                  {listeningSet.status || "DRAFT"}
                </Badge>
                {listeningSet.level ? (
                  <Badge tone="brown">Band {listeningSet.level}</Badge>
                ) : null}
                <Badge tone="sage">{questionCount} câu hỏi</Badge>
              </div>

              <div className="rounded-2xl border border-line bg-paper p-4">
                <p className="text-xs font-semibold uppercase tracking-[.16em] text-neutralText">
                  Listening Set ID
                </p>
                <p className="mt-2 break-all font-mono text-xs text-ink">
                  {listeningSet.id}
                </p>
              </div>

              {listeningSet.audioUrl ? (
                <div className="rounded-2xl border border-line bg-paper p-4">
                  <p className="mb-3 text-sm font-semibold text-ink">
                    Nghe thử
                  </p>
                  <audio controls className="w-full">
                    <source src={listeningSet.audioUrl} />
                    Trình duyệt của bạn không hỗ trợ audio.
                  </audio>
                </div>
              ) : null}

              {listeningSet.tags?.length ? (
                <div className="space-y-2">
                  <p className="text-sm font-semibold text-ink">Tags</p>
                  <div className="flex flex-wrap gap-2">
                    {listeningSet.tags.map((tag) => (
                      <Badge key={tag.id} tone="sage">
                        {tag.name}
                      </Badge>
                    ))}
                  </div>
                </div>
              ) : null}
            </CardContent>
          </Card>

          <Card className="p-5">
            <div className="flex gap-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-line bg-paper">
                <Headphones className="h-4 w-4 text-moss" />
              </div>

              <div>
                <h3 className="font-serif text-xl font-bold text-ink">
                  Điều kiện xuất bản
                </h3>
                <div className="mt-3 space-y-3 text-sm text-neutralText">
                  <div className="rounded-xl border border-line bg-paper p-3">
                    <p className="font-semibold text-ink">1. Có audio</p>
                    <p className="mt-1 text-xs">
                      {listeningSet.audioUrl
                        ? "Đã có audio."
                        : "Chưa có audio."}
                    </p>
                  </div>
                  <div className="rounded-xl border border-line bg-paper p-3">
                    <p className="font-semibold text-ink">2. Có câu hỏi</p>
                    <p className="mt-1 text-xs">
                      Hiện có {questionCount} câu hỏi.
                    </p>
                  </div>
                </div>

                {!isPublished && !canPublish ? (
                  <p className="mt-4 rounded-xl border border-line bg-tertiary/20 p-3 text-xs leading-5 text-warning">
                    Chưa thể xuất bản. Hãy thêm audio và ít nhất một câu hỏi.
                  </p>
                ) : null}
              </div>
            </div>
          </Card>
        </aside>
      </div>
    </div>
  );
}
