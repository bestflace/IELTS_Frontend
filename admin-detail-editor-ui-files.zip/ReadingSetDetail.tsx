"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { ArrowLeft, BookOpen, Eye, RefreshCw, Send } from "lucide-react";

import { Badge } from "@/components/common/Badge";
import { Button } from "@/components/common/Button";
import { Card, CardContent, CardHeader } from "@/components/common/Card";
import { PageHeader } from "@/components/common/PageHeader";
import {
  EmptyState,
  ErrorState,
  LoadingState,
} from "@/components/common/States";
import { ReadingPassageEditor } from "@/components/content-bank/reading/ReadingPassageEditor";
import { ReadingQuestionManager } from "@/components/content-bank/reading/ReadingQuestionManager";
import {
  getAdminReading,
  publishReading,
  unpublishReading,
} from "@/lib/api/reading.api";
import { getErrorMessage } from "@/lib/api/client";
import type { PublishStatus, ReadingSet } from "@/types";

type Props = {
  setId: string;
};

function statusTone(status?: PublishStatus) {
  if (status === "PUBLISHED") return "success";
  if (status === "ARCHIVED") return "danger";
  return "warning";
}

function formatDate(value?: string) {
  if (!value) return "—";

  try {
    return new Intl.DateTimeFormat("vi-VN", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }).format(new Date(value));
  } catch {
    return value;
  }
}

export function ReadingSetDetail({ setId }: Props) {
  const [readingSet, setReadingSet] = useState<ReadingSet | null>(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [error, setError] = useState("");

  const loadData = useCallback(async () => {
    setLoading(true);
    setError("");

    try {
      const data = await getAdminReading(setId);
      setReadingSet(data);
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [setId]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleTogglePublish = async () => {
    if (!readingSet) return;

    setActionLoading(true);
    setError("");

    try {
      if (readingSet.status === "PUBLISHED") {
        await unpublishReading(readingSet.id);
      } else {
        await publishReading(readingSet.id);
      }

      await loadData();
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setActionLoading(false);
    }
  };

  if (loading) {
    return <LoadingState label="Đang tải Reading Set..." />;
  }

  if (error && !readingSet) {
    return <ErrorState message={error} onRetry={loadData} />;
  }

  if (!readingSet) {
    return (
      <EmptyState
        title="Không tìm thấy Reading Set"
        description="Bài đọc có thể đã bị xóa hoặc ID không hợp lệ."
        action={
          <Link href="/admin/reading-sets">
            <Button variant="outline">Quay lại ngân hàng Reading</Button>
          </Link>
        }
      />
    );
  }

  const isPublished = readingSet.status === "PUBLISHED";
  const questionCount = readingSet.questions?.length || 0;
  const canPublish =
    Boolean(readingSet.passageText || readingSet.passageHtml) &&
    questionCount > 0;

  return (
    <div>
      <PageHeader
        eyebrow="Admin / Reading Bank"
        title={readingSet.title}
        description="Quản lý passage, câu hỏi, đáp án và trạng thái xuất bản của Reading Set."
        actions={
          <>
            <Link href="/admin/reading-sets">
              <Button variant="outline">
                <ArrowLeft className="h-4 w-4" />
                Quay lại
              </Button>
            </Link>

            <Button
              variant="outline"
              onClick={loadData}
              disabled={actionLoading}
            >
              <RefreshCw className="h-4 w-4" />
              Làm mới
            </Button>

            <Button
              onClick={handleTogglePublish}
              disabled={actionLoading || (!isPublished && !canPublish)}
              variant={isPublished ? "secondary" : "primary"}
            >
              <Send className="h-4 w-4" />
              {isPublished ? "Gỡ xuất bản" : "Xuất bản"}
            </Button>
          </>
        }
      />

      <div className="grid gap-5 xl:grid-cols-[1fr_360px]">
        <main className="space-y-5">
          {error ? <ErrorState message={error} onRetry={loadData} /> : null}

          <ReadingPassageEditor
            readingSet={readingSet}
            onSaved={setReadingSet}
            onReload={loadData}
          />

          <ReadingQuestionManager
            readingSetId={readingSet.id}
            questions={readingSet.questions || []}
            isPublished={isPublished}
            onChanged={loadData}
          />
        </main>

        <aside className="space-y-4">
          <Card>
            <CardHeader>
              <p className="text-xs font-bold uppercase tracking-[.22em] text-sage">
                Reading overview
              </p>
              <h2 className="mt-1 font-serif text-xl font-bold text-ink">
                Thông tin bài đọc
              </h2>
            </CardHeader>

            <CardContent className="space-y-4">
              <div className="flex flex-wrap gap-2">
                <Badge tone={statusTone(readingSet.status)}>
                  {readingSet.status || "DRAFT"}
                </Badge>

                {readingSet.level ? (
                  <Badge tone="brown">Band {readingSet.level}</Badge>
                ) : null}

                <Badge tone="sage">{questionCount} câu hỏi</Badge>
              </div>

              <div className="rounded-2xl border border-line bg-paper p-4">
                <p className="text-xs font-semibold uppercase tracking-[.16em] text-neutralText">
                  Reading Set ID
                </p>
                <p className="mt-2 break-all font-mono text-xs text-ink">
                  {readingSet.id}
                </p>
              </div>

              <div className="rounded-2xl border border-line bg-paper p-4">
                <p className="text-xs font-semibold uppercase tracking-[.16em] text-neutralText">
                  Cập nhật lần cuối
                </p>
                <p className="mt-2 text-sm font-semibold text-ink">
                  {formatDate(readingSet.updatedAt || readingSet.createdAt)}
                </p>
              </div>

              {readingSet.tags?.length ? (
                <div className="space-y-2">
                  <p className="text-sm font-semibold text-ink">Tags</p>
                  <div className="flex flex-wrap gap-2">
                    {readingSet.tags.map((tag) => (
                      <Badge key={tag.id} tone="sage">
                        {tag.name}
                      </Badge>
                    ))}
                  </div>
                </div>
              ) : null}
            </CardContent>
          </Card>

          <Card className="p-5">
            <div className="flex gap-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-line bg-paper">
                <BookOpen className="h-4 w-4 text-moss" />
              </div>

              <div>
                <h3 className="font-serif text-xl font-bold text-ink">
                  Điều kiện xuất bản
                </h3>

                <div className="mt-3 space-y-3 text-sm text-neutralText">
                  <div className="rounded-xl border border-line bg-paper p-3">
                    <p className="font-semibold text-ink">1. Có passage</p>
                    <p className="mt-1 text-xs">
                      {readingSet.passageText || readingSet.passageHtml
                        ? "Đã có nội dung bài đọc."
                        : "Chưa có passage."}
                    </p>
                  </div>

                  <div className="rounded-xl border border-line bg-paper p-3">
                    <p className="font-semibold text-ink">2. Có câu hỏi</p>
                    <p className="mt-1 text-xs">
                      Hiện có {questionCount} câu hỏi.
                    </p>
                  </div>

                  <div className="rounded-xl border border-line bg-paper p-3">
                    <p className="font-semibold text-ink">3. Đáp án rõ ràng</p>
                    <p className="mt-1 text-xs">
                      Mỗi câu hỏi cần có đáp án để learner được chấm điểm.
                    </p>
                  </div>
                </div>

                {!isPublished && !canPublish ? (
                  <p className="mt-4 rounded-xl border border-line bg-tertiary/20 p-3 text-xs leading-5 text-warning">
                    Chưa thể xuất bản. Hãy nhập passage và thêm ít nhất một câu
                    hỏi.
                  </p>
                ) : null}
              </div>
            </div>
          </Card>

          <Card className="p-5">
            <h3 className="font-serif text-xl font-bold text-ink">Xem nhanh</h3>
            <p className="mt-2 text-sm leading-6 text-neutralText">
              Sau khi xuất bản, Reading Set này có thể được chọn khi tạo đề thi
              thủ công hoặc ngẫu nhiên.
            </p>

            <Link href={`/reading-sets/${readingSet.id}`}>
              <Button variant="outline" className="mt-4 w-full justify-start">
                <Eye className="h-4 w-4" />
                Xem trang public
              </Button>
            </Link>
          </Card>
        </aside>
      </div>
    </div>
  );
}
