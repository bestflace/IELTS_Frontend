"use client";

import { FormEvent, useEffect, useState } from "react";
import { Save } from "lucide-react";

import { Badge } from "@/components/common/Badge";
import { Button } from "@/components/common/Button";
import { Card, CardContent, CardHeader } from "@/components/common/Card";
import { Input } from "@/components/common/Input";
import { Textarea } from "@/components/common/Textarea";
import { ErrorState } from "@/components/common/States";
import { updateReading } from "@/lib/api/reading.api";
import { getErrorMessage } from "@/lib/api/client";
import type { ReadingSet } from "@/types";

type Props = {
  readingSet: ReadingSet;
  onSaved?: (readingSet: ReadingSet) => void;
  onReload?: () => void;
};

const LEVELS = [4, 4.5, 5, 5.5, 6, 6.5, 7, 7.5, 8, 8.5, 9];

export function ReadingPassageEditor({ readingSet, onSaved, onReload }: Props) {
  const [title, setTitle] = useState(readingSet.title || "");
  const [level, setLevel] = useState(
    readingSet.level === null || readingSet.level === undefined
      ? ""
      : String(readingSet.level),
  );
  const [passageText, setPassageText] = useState(readingSet.passageText || "");
  const [passageHtml, setPassageHtml] = useState(readingSet.passageHtml || "");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    setTitle(readingSet.title || "");
    setLevel(
      readingSet.level === null || readingSet.level === undefined
        ? ""
        : String(readingSet.level),
    );
    setPassageText(readingSet.passageText || "");
    setPassageHtml(readingSet.passageHtml || "");
  }, [readingSet]);

  const validate = () => {
    if (!title.trim()) return "Vui lòng nhập tên bài đọc.";
    if (!level) return "Vui lòng chọn band mục tiêu.";

    const numericLevel = Number(level);
    if (Number.isNaN(numericLevel) || numericLevel < 0 || numericLevel > 9) {
      return "Band mục tiêu phải nằm trong khoảng 0 đến 9.";
    }

    if (!passageText.trim() && !passageHtml.trim()) {
      return "Vui lòng nhập passage text hoặc passage HTML.";
    }

    return "";
  };

  const handleSubmit = async (event: FormEvent) => {
    event.preventDefault();

    const validationMessage = validate();
    if (validationMessage) {
      setError(validationMessage);
      return;
    }

    setSaving(true);
    setError("");

    try {
      const updated = await updateReading(readingSet.id, {
        title: title.trim(),
        level: Number(level),
        passageText: passageText.trim() || null,
        passageHtml: passageHtml.trim() || null,
      });

      onSaved?.(updated);
      onReload?.();
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  const isPublished = readingSet.status === "PUBLISHED";

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
          <div>
            <p className="text-xs font-bold uppercase tracking-[.22em] text-sage">
              Passage editor
            </p>
            <h2 className="mt-1 font-serif text-2xl font-bold text-ink">
              Nội dung bài đọc
            </h2>
            <p className="mt-1 text-sm leading-6 text-neutralText">
              Cập nhật tên bài đọc, band mục tiêu và nội dung passage.
            </p>
          </div>

          {isPublished ? (
            <Badge tone="success">PUBLISHED</Badge>
          ) : (
            <Badge tone="warning">DRAFT</Badge>
          )}
        </div>
      </CardHeader>

      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-5">
          {error ? <ErrorState message={error} /> : null}

          {isPublished ? (
            <div className="rounded-2xl border border-line bg-tertiary/20 p-4 text-sm leading-6 text-warning">
              Reading Set này đang được xuất bản. Nếu backend không cho sửa nội
              dung đã publish, hãy gỡ xuất bản trước khi chỉnh sửa.
            </div>
          ) : null}

          <div className="grid gap-4 md:grid-cols-[1fr_180px]">
            <label className="space-y-2">
              <span className="text-sm font-semibold text-ink">
                Tên bài đọc
              </span>
              <Input
                value={title}
                onChange={(event) => setTitle(event.target.value)}
                placeholder="Ví dụ: The History of Tea"
              />
            </label>

            <label className="space-y-2">
              <span className="text-sm font-semibold text-ink">Band</span>
              <select
                value={level}
                onChange={(event) => setLevel(event.target.value)}
                className="h-11 w-full rounded-xl border border-line bg-surface px-3 text-sm text-ink outline-none transition focus:border-moss focus:ring-2 focus:ring-sage/20"
              >
                <option value="">Chọn band</option>
                {LEVELS.map((item) => (
                  <option key={item} value={item}>
                    {item}
                  </option>
                ))}
              </select>
            </label>
          </div>

          <label className="space-y-2 block">
            <span className="text-sm font-semibold text-ink">Passage text</span>
            <Textarea
              value={passageText}
              onChange={(event) => setPassageText(event.target.value)}
              className="min-h-[260px]"
              placeholder="Nhập nội dung passage dạng plain text..."
            />
          </label>

          <label className="space-y-2 block">
            <span className="text-sm font-semibold text-ink">Passage HTML</span>
            <Textarea
              value={passageHtml}
              onChange={(event) => setPassageHtml(event.target.value)}
              className="min-h-[160px] font-mono text-xs"
              placeholder="<p>Nhập passage dạng HTML nếu cần...</p>"
            />
            <p className="text-xs text-neutralText">
              Nếu không cần định dạng HTML, chỉ nhập Passage text là đủ.
            </p>
          </label>

          <div className="flex justify-end">
            <Button type="submit" disabled={saving}>
              <Save className="h-4 w-4" />
              {saving ? "Đang lưu..." : "Lưu nội dung bài đọc"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
