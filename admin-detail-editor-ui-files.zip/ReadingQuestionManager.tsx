"use client";

import { useMemo, useState } from "react";
import { Edit3, Plus, Trash2 } from "lucide-react";

import { Badge } from "@/components/common/Badge";
import { Button } from "@/components/common/Button";
import { Card, CardContent, CardHeader } from "@/components/common/Card";
import { ConfirmDialog, Modal } from "@/components/common/Modal";
import { EmptyState, ErrorState } from "@/components/common/States";
import { ReadingQuestionForm } from "@/components/content-bank/reading/ReadingQuestionForm";
import {
  addReadingQuestion,
  deleteReadingQuestion,
  updateReadingQuestion,
} from "@/lib/api/reading.api";
import { getErrorMessage } from "@/lib/api/client";
import type { Question } from "@/types";
import type { QuestionInput } from "@/lib/api/reading.api";

type Props = {
  readingSetId: string;
  questions: Question[];
  isPublished?: boolean;
  onChanged?: () => void;
};

function stringifyJson(value: unknown) {
  if (value === null || value === undefined) return "—";
  if (typeof value === "string") return value;

  try {
    return JSON.stringify(value);
  } catch {
    return String(value);
  }
}

function sortQuestions(questions: Question[]) {
  return [...questions].sort(
    (a, b) => (a.sortOrder || a.qNo || 0) - (b.sortOrder || b.qNo || 0),
  );
}

export function ReadingQuestionManager({
  readingSetId,
  questions,
  isPublished = false,
  onChanged,
}: Props) {
  const [formOpen, setFormOpen] = useState(false);
  const [editingQuestion, setEditingQuestion] = useState<Question | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Question | null>(null);
  const [actionLoading, setActionLoading] = useState(false);
  const [error, setError] = useState("");

  const sortedQuestions = useMemo(() => sortQuestions(questions), [questions]);
  const nextSortOrder = sortedQuestions.length + 1;

  const openCreateForm = () => {
    setEditingQuestion(null);
    setFormOpen(true);
    setError("");
  };

  const openEditForm = (question: Question) => {
    setEditingQuestion(question);
    setFormOpen(true);
    setError("");
  };

  const handleSubmit = async (payload: QuestionInput) => {
    setActionLoading(true);
    setError("");

    try {
      if (editingQuestion?.id) {
        await updateReadingQuestion(editingQuestion.id, payload);
      } else {
        await addReadingQuestion(readingSetId, payload);
      }

      setFormOpen(false);
      setEditingQuestion(null);
      onChanged?.();
    } catch (err) {
      setError(getErrorMessage(err));
      throw err;
    } finally {
      setActionLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget?.id) return;

    setActionLoading(true);
    setError("");

    try {
      await deleteReadingQuestion(deleteTarget.id);
      setDeleteTarget(null);
      onChanged?.();
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setActionLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div>
            <p className="text-xs font-bold uppercase tracking-[.22em] text-sage">
              Question manager
            </p>
            <h2 className="mt-1 font-serif text-2xl font-bold text-ink">
              Câu hỏi Reading
            </h2>
            <p className="mt-1 text-sm leading-6 text-neutralText">
              Quản lý câu hỏi, lựa chọn, đáp án đúng và thứ tự hiển thị.
            </p>
          </div>

          <Button onClick={openCreateForm} disabled={isPublished}>
            <Plus className="h-4 w-4" />
            Thêm câu hỏi
          </Button>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {error ? <ErrorState message={error} /> : null}

        {isPublished ? (
          <div className="rounded-2xl border border-line bg-tertiary/20 p-4 text-sm leading-6 text-warning">
            Reading Set này đang được xuất bản. Nếu backend không cho sửa câu
            hỏi đã publish, hãy gỡ xuất bản trước khi chỉnh sửa.
          </div>
        ) : null}

        {sortedQuestions.length ? (
          <div className="overflow-hidden rounded-2xl border border-line">
            <table className="w-full min-w-[900px] border-collapse bg-surface text-sm">
              <thead className="bg-cream/70 text-left">
                <tr className="border-b border-line">
                  <th className="px-4 py-3 font-semibold text-ink">Câu</th>
                  <th className="px-4 py-3 font-semibold text-ink">Loại</th>
                  <th className="px-4 py-3 font-semibold text-ink">Nội dung</th>
                  <th className="px-4 py-3 font-semibold text-ink">Đáp án</th>
                  <th className="px-4 py-3 font-semibold text-ink">Điểm</th>
                  <th className="px-4 py-3 text-right font-semibold text-ink">
                    Thao tác
                  </th>
                </tr>
              </thead>

              <tbody>
                {sortedQuestions.map((question, index) => (
                  <tr
                    key={question.id || index}
                    className="border-b border-line last:border-b-0"
                  >
                    <td className="px-4 py-4 align-top">
                      <Badge tone="sage">Q{question.qNo || index + 1}</Badge>
                    </td>

                    <td className="px-4 py-4 align-top">
                      <Badge tone="brown">
                        {String(question.questionType || "—")}
                      </Badge>
                    </td>

                    <td className="px-4 py-4 align-top">
                      {question.instructionText ? (
                        <p className="mb-1 text-xs font-semibold uppercase tracking-[.14em] text-sage">
                          {question.instructionText}
                        </p>
                      ) : null}

                      <p className="line-clamp-3 max-w-xl text-sm leading-6 text-ink">
                        {question.promptText || "Chưa có nội dung câu hỏi."}
                      </p>

                      <p className="mt-1 text-xs text-neutralText">
                        Sort order: {question.sortOrder || index + 1}
                      </p>
                    </td>

                    <td className="px-4 py-4 align-top">
                      <code className="line-clamp-3 block max-w-[260px] rounded-xl border border-line bg-paper p-2 text-xs text-neutralText">
                        {stringifyJson(question.correctAnswerJson)}
                      </code>
                    </td>

                    <td className="px-4 py-4 align-top">
                      <span className="font-semibold text-ink">
                        {question.points ?? 1}
                      </span>
                    </td>

                    <td className="px-4 py-4 align-top">
                      <div className="flex justify-end gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => openEditForm(question)}
                          disabled={isPublished}
                        >
                          <Edit3 className="h-4 w-4" />
                          Sửa
                        </Button>

                        <Button
                          size="sm"
                          variant="danger"
                          onClick={() => setDeleteTarget(question)}
                          disabled={isPublished}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            title="Chưa có câu hỏi"
            description="Thêm câu hỏi để Reading Set có thể được xuất bản và sử dụng trong đề thi."
            action={
              <Button onClick={openCreateForm} disabled={isPublished}>
                <Plus className="h-4 w-4" />
                Thêm câu hỏi đầu tiên
              </Button>
            }
          />
        )}
      </CardContent>

      <Modal
        open={formOpen}
        onClose={() => {
          setFormOpen(false);
          setEditingQuestion(null);
        }}
        title={editingQuestion ? "Sửa câu hỏi Reading" : "Thêm câu hỏi Reading"}
      >
        <ReadingQuestionForm
          initialData={editingQuestion}
          nextSortOrder={nextSortOrder}
          onSubmit={handleSubmit}
          onCancel={() => {
            setFormOpen(false);
            setEditingQuestion(null);
          }}
        />
      </Modal>

      <ConfirmDialog
        open={Boolean(deleteTarget)}
        title="Xóa câu hỏi?"
        description="Câu hỏi này sẽ bị xóa khỏi Reading Set. Thao tác này không xóa passage."
        onCancel={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
      />
    </Card>
  );
}
