"use client";

import { useCallback, useEffect, useState } from "react";
import { MessageSquareText, RefreshCw } from "lucide-react";

import { Button } from "@/components/common/Button";
import { Card, CardContent, CardHeader } from "@/components/common/Card";
import { ErrorState, LoadingState } from "@/components/common/States";
import { CommentForm } from "@/components/comments/CommentForm";
import { CommentList } from "@/components/comments/CommentList";
import {
  createAttemptComment,
  getAttemptComments,
} from "@/lib/api/comments.api";
import { getErrorMessage } from "@/lib/api/client";

type Props = {
  attemptId: string;
  canModerate?: boolean;
  currentUserId?: string;
  title?: string;
  description?: string;
};

function extractItems(response: any) {
  if (Array.isArray(response)) return response;
  if (Array.isArray(response?.items)) return response.items;
  if (Array.isArray(response?.data)) return response.data;
  if (Array.isArray(response?.data?.items)) return response.data.items;
  return [];
}

export function DiscussionPanel({
  attemptId,
  canModerate = false,
  currentUserId,
  title = "Thảo luận bài làm",
  description = "Học viên có thể đặt câu hỏi về bài làm, giáo viên có thể phản hồi để giải thích rõ hơn.",
}: Props) {
  const [comments, setComments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState("");

  const loadComments = useCallback(async () => {
    setLoading(true);
    setError("");

    try {
      const response = await getAttemptComments(attemptId);
      setComments(extractItems(response));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [attemptId]);

  useEffect(() => {
    loadComments();
  }, [loadComments]);

  const handleCreate = async (content: string) => {
    setSending(true);
    setError("");

    try {
      await createAttemptComment(attemptId, {
        content,
        parentId: null,
      });

      await loadComments();
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setSending(false);
    }
  };

  return (
    <Card className="rounded-[28px] border border-line bg-surface">
      <CardHeader>
        <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
          <div className="flex items-start gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primarySoft">
              <MessageSquareText className="h-6 w-6 text-moss" />
            </div>

            <div>
              <p className="text-xs font-bold uppercase tracking-[.22em] text-sage">
                Discussion
              </p>

              <h2 className="mt-1 font-serif text-2xl font-bold text-ink">
                {title}
              </h2>

              <p className="mt-1 text-sm leading-6 text-neutralText">
                {description}
              </p>
            </div>
          </div>

          <Button type="button" variant="outline" onClick={loadComments}>
            <RefreshCw className="h-4 w-4" />
            Làm mới
          </Button>
        </div>
      </CardHeader>

      <CardContent className="space-y-5">
        {error ? <ErrorState message={error} onRetry={loadComments} /> : null}

        <CommentForm loading={sending} onSubmit={handleCreate} />

        {loading ? (
          <LoadingState label="Đang tải thảo luận..." />
        ) : (
          <CommentList
            attemptId={attemptId}
            comments={comments}
            canModerate={canModerate}
            currentUserId={currentUserId}
            onChanged={loadComments}
            onError={setError}
          />
        )}
      </CardContent>
    </Card>
  );
}
