"use client";

import { MessageCircle } from "lucide-react";

import {
  CommentItem,
  type CommentModel,
} from "@/components/comments/CommentItem";

type Props = {
  attemptId: string;
  comments: CommentModel[];
  canModerate?: boolean;
  currentUserId?: string;
  onChanged?: () => void;
  onError?: (message: string) => void;
};

export function CommentList({
  attemptId,
  comments,
  canModerate = false,
  currentUserId,
  onChanged,
  onError,
}: Props) {
  if (!comments.length) {
    return (
      <div className="rounded-2xl border border-dashed border-line bg-paper p-8 text-center">
        <MessageCircle className="mx-auto h-10 w-10 text-neutralText" />
        <h3 className="mt-4 font-serif text-xl font-bold text-ink">
          Chưa có trao đổi nào
        </h3>
        <p className="mt-2 text-sm leading-6 text-neutralText">
          Học viên có thể đặt câu hỏi dưới bài làm, giáo viên có thể phản hồi
          tại đây.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {comments.map((comment) => (
        <CommentItem
          key={comment.id}
          attemptId={attemptId}
          comment={comment}
          canModerate={canModerate}
          currentUserId={currentUserId}
          onChanged={onChanged}
          onError={onError}
        />
      ))}
    </div>
  );
}
