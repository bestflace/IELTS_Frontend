"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Eye, RefreshCw, Search, Send, Trash2 } from "lucide-react";

import { Badge } from "@/components/common/Badge";
import { Button } from "@/components/common/Button";
import { Card, CardContent, CardHeader } from "@/components/common/Card";
import { ConfirmDialog } from "@/components/common/Modal";
import { Input } from "@/components/common/Input";
import {
  EmptyState,
  ErrorState,
  LoadingState,
} from "@/components/common/States";
import {
  deleteListening,
  getAdminListeningList,
  publishListening,
  unpublishListening,
} from "@/lib/api/listening.api";
import { getErrorMessage } from "@/lib/api/client";
import type { ListeningSet, PublishStatus } from "@/types";

const statusOptions: Array<{ label: string; value: "" | PublishStatus }> = [
  { label: "Tất cả trạng thái", value: "" },
  { label: "Draft", value: "DRAFT" },
  { label: "Published", value: "PUBLISHED" },
  { label: "Archived", value: "ARCHIVED" },
];

function statusTone(status?: PublishStatus) {
  if (status === "PUBLISHED") return "success";
  if (status === "ARCHIVED") return "danger";
  return "warning";
}

function formatDate(value?: string) {
  if (!value) return "—";

  try {
    return new Intl.DateTimeFormat("vi-VN", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    }).format(new Date(value));
  } catch {
    return value;
  }
}

export function ListeningSetTable() {
  const [items, setItems] = useState<ListeningSet[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [error, setError] = useState("");
  const [keyword, setKeyword] = useState("");
  const [status, setStatus] = useState<"" | PublishStatus>("");
  const [deleteTarget, setDeleteTarget] = useState<ListeningSet | null>(null);

  const loadData = useCallback(async () => {
    setLoading(true);
    setError("");

    try {
      const res = await getAdminListeningList({
        search: keyword.trim() || undefined,
        status: status || undefined,
      });

      setItems(res.data || []);
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [keyword, status]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const filteredItems = useMemo(() => {
    const normalizedKeyword = keyword.trim().toLowerCase();

    return items.filter((item) => {
      const matchKeyword = normalizedKeyword
        ? `${item.title} ${item.transcriptText || ""}`
            .toLowerCase()
            .includes(normalizedKeyword)
        : true;

      const matchStatus = status ? item.status === status : true;

      return matchKeyword && matchStatus;
    });
  }, [items, keyword, status]);

  const handlePublish = async (item: ListeningSet) => {
    setActionLoading(true);
    setError("");

    try {
      if (item.status === "PUBLISHED") {
        await unpublishListening(item.id);
      } else {
        await publishListening(item.id);
      }

      await loadData();
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setActionLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;

    setActionLoading(true);
    setError("");

    try {
      await deleteListening(deleteTarget.id);
      setDeleteTarget(null);
      await loadData();
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setActionLoading(false);
    }
  };

  if (loading) return <LoadingState label="Đang tải ngân hàng Listening..." />;

  if (error && !items.length) {
    return <ErrorState message={error} onRetry={loadData} />;
  }

  return (
    <div className="space-y-5">
      {error ? <ErrorState message={error} onRetry={loadData} /> : null}

      <Card>
        <CardHeader>
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <p className="text-xs font-bold uppercase tracking-[.22em] text-sage">
                Listening Bank
              </p>
              <h2 className="mt-1 font-serif text-2xl font-bold text-ink">
                Danh sách Listening Set
              </h2>
              <p className="mt-1 text-sm text-neutralText">
                Chỉ những Listening Set đã xuất bản mới được chọn khi tạo đề
                thi.
              </p>
            </div>

            <Button
              variant="outline"
              onClick={loadData}
              disabled={actionLoading}
            >
              <RefreshCw className="h-4 w-4" />
              Làm mới
            </Button>
          </div>
        </CardHeader>

        <CardContent>
          <div className="mb-5 grid gap-3 lg:grid-cols-[1fr_220px]">
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-3.5 h-4 w-4 text-neutralText" />
              <Input
                value={keyword}
                onChange={(event) => setKeyword(event.target.value)}
                className="pl-9"
                placeholder="Tìm theo tên bài nghe hoặc transcript..."
              />
            </div>

            <select
              value={status}
              onChange={(event) =>
                setStatus(event.target.value as "" | PublishStatus)
              }
              className="h-11 w-full rounded-xl border border-line bg-surface px-3 text-sm text-ink outline-none transition focus:border-moss focus:ring-2 focus:ring-sage/20"
            >
              {statusOptions.map((option) => (
                <option key={option.label} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>

          {filteredItems.length ? (
            <div className="overflow-hidden rounded-2xl border border-line">
              <table className="w-full min-w-[900px] border-collapse bg-surface text-sm">
                <thead className="bg-cream/70 text-left">
                  <tr className="border-b border-line">
                    <th className="px-4 py-3 font-semibold text-ink">
                      Listening Set
                    </th>
                    <th className="px-4 py-3 font-semibold text-ink">Band</th>
                    <th className="px-4 py-3 font-semibold text-ink">
                      Trạng thái
                    </th>
                    <th className="px-4 py-3 font-semibold text-ink">Audio</th>
                    <th className="px-4 py-3 font-semibold text-ink">
                      Câu hỏi
                    </th>
                    <th className="px-4 py-3 font-semibold text-ink">
                      Cập nhật
                    </th>
                    <th className="px-4 py-3 text-right font-semibold text-ink">
                      Thao tác
                    </th>
                  </tr>
                </thead>

                <tbody>
                  {filteredItems.map((item) => (
                    <tr
                      key={item.id}
                      className="border-b border-line last:border-b-0"
                    >
                      <td className="px-4 py-4 align-top">
                        <p className="font-semibold text-ink">{item.title}</p>
                        {item.transcriptText ? (
                          <p className="mt-1 line-clamp-2 max-w-xl text-xs leading-5 text-neutralText">
                            {item.transcriptText}
                          </p>
                        ) : null}
                      </td>

                      <td className="px-4 py-4 align-top">
                        <span className="text-sm text-ink">
                          {item.level ? item.level : "—"}
                        </span>
                      </td>

                      <td className="px-4 py-4 align-top">
                        <span className="text-sm text-ink">
                          {item.status === "PUBLISHED"
                            ? "Đã xuất bản"
                            : item.status === "ARCHIVED"
                              ? "Lưu trữ"
                              : "Bản nháp"}
                        </span>
                      </td>

                      <td className="px-4 py-4 align-top">
                        <span className="text-sm text-ink">
                          {item.audioUrl ? "Có audio" : "Chưa có"}
                        </span>
                      </td>

                      <td className="px-4 py-4 align-top">
                        <span className="font-semibold text-ink">
                          {item.questions?.length || 0}
                        </span>
                      </td>

                      <td className="px-4 py-4 align-top text-xs text-neutralText">
                        {formatDate(item.updatedAt || item.createdAt)}
                      </td>

                      <td className="px-4 py-4 align-top">
                        <div className="flex justify-end gap-2">
                          <Link href={`/admin/listening-sets/${item.id}`}>
                            <Button size="sm" variant="outline">
                              <Eye className="h-4 w-4" />
                              Chi tiết
                            </Button>
                          </Link>

                          <Button
                            size="sm"
                            variant={
                              item.status === "PUBLISHED"
                                ? "secondary"
                                : "outline"
                            }
                            onClick={() => handlePublish(item)}
                            disabled={actionLoading}
                          >
                            <Send className="h-4 w-4" />
                            {item.status === "PUBLISHED" ? "Gỡ" : "Publish"}
                          </Button>

                          <Button
                            size="sm"
                            variant="danger"
                            onClick={() => setDeleteTarget(item)}
                            disabled={
                              actionLoading || item.status === "PUBLISHED"
                            }
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <EmptyState
              title="Chưa có Listening Set"
              description="Tạo bài nghe đầu tiên để bắt đầu xây dựng ngân hàng Listening."
              action={
                <Link href="/admin/listening-sets/new">
                  <Button>Tạo Listening Set</Button>
                </Link>
              }
            />
          )}
        </CardContent>
      </Card>

      <ConfirmDialog
        open={Boolean(deleteTarget)}
        title="Xóa Listening Set?"
        description="Listening Set này sẽ bị xóa khỏi ngân hàng đề. Không nên xóa nếu nội dung đã được dùng trong đề thi."
        onCancel={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
      />
    </div>
  );
}
