"use client";

import { Mail, UserRound } from "lucide-react";

import { Card, CardContent } from "@/components/common/Card";
import type { User } from "@/types";
import { displayName } from "@/types";
import { UserRoleBadge } from "@/components/users/UserRoleBadge";
import { UserStatusBadge } from "@/components/users/UserStatusBadge";

function getAvatar(user: User) {
  return user.avatarUrl || user.avatar_url || "";
}

function formatDate(value?: string | null) {
  if (!value) return "—";

  try {
    return new Intl.DateTimeFormat("vi-VN", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }).format(new Date(value));
  } catch {
    return value;
  }
}

export function UserDetailCard({ user }: { user: User }) {
  const name = displayName(user);
  const avatar = getAvatar(user);

  return (
    <Card className="rounded-[24px] border border-line bg-surface">
      <CardContent className="p-6">
        <div className="flex flex-col gap-5 md:flex-row md:items-start">
          {avatar ? (
            <img
              src={avatar}
              alt={name}
              className="h-24 w-24 rounded-full border border-line object-cover"
            />
          ) : (
            <div className="flex h-24 w-24 shrink-0 items-center justify-center rounded-full border border-line bg-primarySoft text-4xl font-bold text-moss">
              {name.slice(0, 1).toUpperCase()}
            </div>
          )}

          <div className="flex-1">
            <h2 className="font-serif text-3xl font-bold text-ink">{name}</h2>

            <div className="mt-2 flex items-center gap-2 text-sm text-neutralText">
              <Mail className="h-4 w-4" />
              {user.email}
            </div>

            <div className="mt-4 flex flex-wrap gap-2">
              <UserRoleBadge role={user.role} />
              <UserStatusBadge status={user.status} />
            </div>

            <div className="mt-5 grid gap-3 md:grid-cols-2">
              <div className="rounded-2xl border border-line bg-paper p-4">
                <p className="text-xs font-bold uppercase tracking-[.16em] text-neutralText">
                  Loại tài khoản
                </p>
                <p className="mt-2 text-sm font-semibold text-ink">
                  {user.role === "ADMIN"
                    ? "Quản trị viên hệ thống"
                    : user.role === "TEACHER"
                      ? "Giáo viên chấm bài"
                      : "Học viên luyện thi"}
                </p>
              </div>

              <div className="rounded-2xl border border-line bg-paper p-4">
                <p className="text-xs font-bold uppercase tracking-[.16em] text-neutralText">
                  Ngày tạo tài khoản
                </p>
                <p className="mt-2 text-sm text-ink">
                  {formatDate(user.createdAt || user.created_at)}
                </p>
              </div>
            </div>
          </div>

          <UserRound className="hidden h-10 w-10 text-neutralText/40 md:block" />
        </div>
      </CardContent>
    </Card>
  );
}
