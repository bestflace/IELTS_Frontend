"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Edit3, Eye, Lock, RefreshCw, ShieldCheck, Unlock } from "lucide-react";

import { Button } from "@/components/common/Button";
import { Card, CardContent, CardHeader } from "@/components/common/Card";
import {
  EmptyState,
  ErrorState,
  LoadingState,
} from "@/components/common/States";
import { getErrorMessage } from "@/lib/api/client";
import {
  getUsers,
  updateUser,
  updateUserRole,
  updateUserStatus,
} from "@/lib/api/users.api";
import type { BackendRole, User, UserStatus } from "@/types";
import { displayName } from "@/types";
import { UserFilterBar } from "@/components/users/UserFilterBar";
import { UserRoleBadge } from "@/components/users/UserRoleBadge";
import { UserStatusBadge } from "@/components/users/UserStatusBadge";
import { ChangeRoleModal } from "@/components/users/ChangeRoleModal";
import { ChangeStatusModal } from "@/components/users/ChangeStatusModal";
import { EditUserModal } from "@/components/users/EditUserModal";
import { UserDetailCard } from "@/components/users/UserDetailCard";

function getAvatar(user: User) {
  return user.avatarUrl || user.avatar_url || "";
}

function formatDate(value?: string | null) {
  if (!value) return "—";

  try {
    return new Intl.DateTimeFormat("vi-VN", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    }).format(new Date(value));
  } catch {
    return value;
  }
}

export function UserTable() {
  const [items, setItems] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [error, setError] = useState("");

  const [keyword, setKeyword] = useState("");
  const [role, setRole] = useState<"" | BackendRole>("");
  const [status, setStatus] = useState<"" | UserStatus>("");

  const [detailTarget, setDetailTarget] = useState<User | null>(null);
  const [editTarget, setEditTarget] = useState<User | null>(null);
  const [roleTarget, setRoleTarget] = useState<User | null>(null);
  const [statusTarget, setStatusTarget] = useState<User | null>(null);

  const loadData = useCallback(async () => {
    setLoading(true);
    setError("");

    try {
      const res = await getUsers({
        search: keyword.trim() || undefined,
        role: role || undefined,
        status: status || undefined,
        limit: 100,
      });

      setItems(res.data || []);
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [keyword, role, status]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const counts = useMemo(() => {
    return {
      total: items.length,
      learners: items.filter((item) => item.role === "USER").length,
      teachers: items.filter((item) => item.role === "TEACHER").length,
      admins: items.filter((item) => item.role === "ADMIN").length,
      active: items.filter((item) => item.status === "ACTIVE").length,
    };
  }, [items]);

  const filteredItems = useMemo(() => {
    const normalized = keyword.trim().toLowerCase();

    return items.filter((user) => {
      const matchKeyword = normalized
        ? `${displayName(user)} ${user.email}`
            .toLowerCase()
            .includes(normalized)
        : true;

      const matchRole = role ? user.role === role : true;
      const matchStatus = status ? user.status === status : true;

      return matchKeyword && matchRole && matchStatus;
    });
  }, [items, keyword, role, status]);

  const handleChangeRole = async (nextRole: BackendRole) => {
    if (!roleTarget) return;

    setActionLoading(true);
    setError("");

    try {
      await updateUserRole(roleTarget.id, { role: nextRole });
      setRoleTarget(null);
      await loadData();
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setActionLoading(false);
    }
  };

  const handleChangeStatus = async (nextStatus: UserStatus) => {
    if (!statusTarget) return;

    setActionLoading(true);
    setError("");

    try {
      await updateUserStatus(statusTarget.id, { status: nextStatus });
      setStatusTarget(null);
      await loadData();
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setActionLoading(false);
    }
  };

  const handleEditUser = async (data: {
    fullName?: string;
    role: BackendRole;
    status: UserStatus;
  }) => {
    if (!editTarget) return;

    setActionLoading(true);
    setError("");

    try {
      await updateUser(editTarget.id, data);
      setEditTarget(null);
      await loadData();
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setActionLoading(false);
    }
  };

  if (loading) {
    return <LoadingState label="Đang tải danh sách người dùng..." />;
  }

  if (error && !items.length) {
    return <ErrorState message={error} onRetry={loadData} />;
  }

  return (
    <div className="space-y-5">
      {error ? <ErrorState message={error} onRetry={loadData} /> : null}

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <Card className="rounded-[22px] border border-line bg-surface">
          <CardContent className="p-5">
            <p className="text-xs font-bold uppercase tracking-[.18em] text-neutralText">
              Tổng người dùng
            </p>
            <p className="mt-2 font-serif text-3xl font-bold text-ink">
              {counts.total}
            </p>
          </CardContent>
        </Card>

        <Card className="rounded-[22px] border border-line bg-surface">
          <CardContent className="p-5">
            <p className="text-xs font-bold uppercase tracking-[.18em] text-neutralText">
              Học viên
            </p>
            <p className="mt-2 font-serif text-3xl font-bold text-ink">
              {counts.learners}
            </p>
          </CardContent>
        </Card>

        <Card className="rounded-[22px] border border-line bg-surface">
          <CardContent className="p-5">
            <p className="text-xs font-bold uppercase tracking-[.18em] text-neutralText">
              Giáo viên
            </p>
            <p className="mt-2 font-serif text-3xl font-bold text-ink">
              {counts.teachers}
            </p>
          </CardContent>
        </Card>

        <Card className="rounded-[22px] border border-line bg-surface">
          <CardContent className="p-5">
            <p className="text-xs font-bold uppercase tracking-[.18em] text-neutralText">
              Đang hoạt động
            </p>
            <p className="mt-2 font-serif text-3xl font-bold text-ink">
              {counts.active}
            </p>
          </CardContent>
        </Card>
      </div>

      <Card className="overflow-hidden rounded-[26px] border border-line bg-surface">
        <CardHeader>
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <p className="text-xs font-bold uppercase tracking-[.22em] text-sage">
                User manager
              </p>
              <h2 className="mt-1 font-serif text-2xl font-bold text-ink">
                Danh sách người dùng
              </h2>
              <p className="mt-1 text-sm text-neutralText">
                Tìm kiếm, lọc vai trò, cập nhật trạng thái và phân quyền tài
                khoản.
              </p>
            </div>

            <Button
              variant="outline"
              onClick={loadData}
              disabled={actionLoading}
            >
              <RefreshCw className="h-4 w-4" />
              Làm mới
            </Button>
          </div>
        </CardHeader>

        <CardContent>
          <div className="mb-5">
            <UserFilterBar
              keyword={keyword}
              role={role}
              status={status}
              onKeywordChange={setKeyword}
              onRoleChange={setRole}
              onStatusChange={setStatus}
            />
          </div>

          {filteredItems.length ? (
            <div className="overflow-hidden rounded-2xl border border-line">
              <table className="w-full min-w-[1050px] border-collapse bg-surface text-sm">
                <thead className="bg-cream/70 text-left">
                  <tr className="border-b border-line">
                    <th className="px-4 py-3 font-semibold text-ink">
                      Người dùng
                    </th>
                    <th className="px-4 py-3 font-semibold text-ink">Email</th>
                    <th className="px-4 py-3 font-semibold text-ink">
                      Vai trò
                    </th>
                    <th className="px-4 py-3 font-semibold text-ink">
                      Trạng thái
                    </th>
                    <th className="px-4 py-3 font-semibold text-ink">
                      Ngày tạo
                    </th>
                    <th className="px-4 py-3 text-right font-semibold text-ink">
                      Thao tác
                    </th>
                  </tr>
                </thead>

                <tbody>
                  {filteredItems.map((user) => {
                    const avatar = getAvatar(user);
                    const name = displayName(user);

                    return (
                      <tr
                        key={user.id}
                        className="border-b border-line last:border-b-0"
                      >
                        <td className="px-4 py-4 align-top">
                          <div className="flex items-center gap-3">
                            {avatar ? (
                              <img
                                src={avatar}
                                alt={name}
                                className="h-10 w-10 rounded-full border border-line object-cover"
                              />
                            ) : (
                              <div className="flex h-10 w-10 items-center justify-center rounded-full border border-line bg-primarySoft text-sm font-bold text-moss">
                                {name.slice(0, 1).toUpperCase()}
                              </div>
                            )}

                            <div>
                              <p className="font-semibold text-ink">{name}</p>
                              <p className="text-xs text-neutralText">
                                {user.role === "ADMIN"
                                  ? "Tài khoản quản trị"
                                  : user.role === "TEACHER"
                                    ? "Tài khoản giáo viên"
                                    : "Tài khoản học viên"}
                              </p>
                            </div>
                          </div>
                        </td>

                        <td className="px-4 py-4 align-top text-ink">
                          {user.email}
                        </td>

                        <td className="px-4 py-4 align-top">
                          <UserRoleBadge role={user.role} />
                        </td>

                        <td className="px-4 py-4 align-top">
                          <UserStatusBadge status={user.status} />
                        </td>

                        <td className="px-4 py-4 align-top text-sm text-neutralText">
                          {formatDate(user.createdAt || user.created_at)}
                        </td>

                        <td className="px-4 py-4 align-top">
                          <div className="flex justify-end gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => setDetailTarget(user)}
                            >
                              <Eye className="h-4 w-4" />
                              Chi tiết
                            </Button>

                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => setEditTarget(user)}
                              disabled={actionLoading}
                            >
                              <Edit3 className="h-4 w-4" />
                              Sửa
                            </Button>

                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => setRoleTarget(user)}
                              disabled={actionLoading}
                            >
                              <ShieldCheck className="h-4 w-4" />
                              Quyền
                            </Button>

                            <Button
                              size="sm"
                              variant={
                                user.status === "BLOCKED" ? "outline" : "danger"
                              }
                              onClick={() => setStatusTarget(user)}
                              disabled={actionLoading}
                            >
                              {user.status === "BLOCKED" ? (
                                <Unlock className="h-4 w-4" />
                              ) : (
                                <Lock className="h-4 w-4" />
                              )}
                              {user.status === "BLOCKED" ? "Mở khóa" : "Khóa"}
                            </Button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            <EmptyState
              title="Không tìm thấy người dùng"
              description="Thử đổi từ khóa, vai trò hoặc trạng thái lọc."
            />
          )}
        </CardContent>
      </Card>

      <ChangeRoleModal
        open={Boolean(roleTarget)}
        user={roleTarget}
        loading={actionLoading}
        onClose={() => setRoleTarget(null)}
        onConfirm={handleChangeRole}
      />

      <ChangeStatusModal
        open={Boolean(statusTarget)}
        user={statusTarget}
        loading={actionLoading}
        onClose={() => setStatusTarget(null)}
        onConfirm={handleChangeStatus}
      />

      <EditUserModal
        open={Boolean(editTarget)}
        user={editTarget}
        loading={actionLoading}
        onClose={() => setEditTarget(null)}
        onSubmit={handleEditUser}
      />

      {detailTarget ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30 p-4">
          <div className="max-h-[90vh] w-full max-w-4xl overflow-y-auto rounded-[28px] bg-surface p-5 shadow-xl">
            <div className="mb-4 flex justify-end">
              <Button variant="outline" onClick={() => setDetailTarget(null)}>
                Đóng
              </Button>
            </div>

            <UserDetailCard user={detailTarget} />
          </div>
        </div>
      ) : null}
    </div>
  );
}
