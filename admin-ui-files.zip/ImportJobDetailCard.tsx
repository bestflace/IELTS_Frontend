"use client";

import {
  AlertTriangle,
  CheckCircle2,
  Clock3,
  ExternalLink,
  FileSpreadsheet,
  UserRound,
  XCircle,
} from "lucide-react";
import Link from "next/link";

import { Button } from "@/components/common/Button";
import { Card, CardContent, CardHeader } from "@/components/common/Card";
import type { ImportJob } from "@/lib/api/imports.api";
import { ImportJobStatusBadge } from "./ImportJobStatusBadge";
import { getImportTypeText } from "./ImportTypeSelector";

type Props = {
  job: ImportJob;
};

function getFileUrl(job?: ImportJob | null) {
  return job?.fileUrl || job?.file_url || "";
}

function getResultJson(job?: ImportJob | null) {
  return job?.resultJson ?? job?.result_json ?? null;
}

function getErrorMessageFromJob(job?: ImportJob | null) {
  return job?.errorMessage || job?.error_message || "";
}

function getCreatedDate(job?: ImportJob | null) {
  return job?.createdAt || job?.created_at || job?.updatedAt || job?.updated_at;
}

function getStartedDate(job?: ImportJob | null) {
  return job?.startedAt || job?.started_at || null;
}

function getFinishedDate(job?: ImportJob | null) {
  return job?.finishedAt || job?.finished_at || null;
}

function getUploaderName(job?: ImportJob | null) {
  return (
    job?.uploader?.fullName ||
    job?.uploader?.full_name ||
    job?.uploader?.email ||
    job?.uploadedBy ||
    job?.uploaded_by ||
    "Quản trị viên"
  );
}

function formatDate(value?: string | null) {
  if (!value) return "—";

  try {
    return new Intl.DateTimeFormat("vi-VN", {
      hour: "2-digit",
      minute: "2-digit",
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    }).format(new Date(value));
  } catch {
    return value;
  }
}

function readResultNumber(result: any, keys: string[]) {
  for (const key of keys) {
    const value = result?.[key];

    if (value !== undefined && value !== null) return value;
  }

  return "—";
}

function JsonPreview({ value }: { value: unknown }) {
  if (!value) {
    return (
      <p className="text-sm leading-6 text-neutralText">
        Worker chưa ghi kết quả xử lý cho job này.
      </p>
    );
  }

  return (
    <pre className="max-h-[360px] overflow-auto rounded-2xl border border-line bg-paper p-4 text-xs leading-6 text-ink">
      {JSON.stringify(value, null, 2)}
    </pre>
  );
}

export function ImportJobDetailCard({ job }: Props) {
  const resultJson = getResultJson(job) as any;
  const fileUrl = getFileUrl(job);
  const errorMessage = getErrorMessageFromJob(job);

  return (
    <div className="space-y-6">
      <section className="overflow-hidden rounded-[32px] border border-line bg-surface shadow-sm">
        <div className="grid gap-6 p-7 xl:grid-cols-[1fr_380px] xl:p-9">
          <div>
            <p className="text-xs font-bold uppercase tracking-[.24em] text-sage">
              Import job detail
            </p>

            <h1 className="mt-3 break-all font-serif text-4xl font-bold leading-tight text-ink md:text-5xl">
              Job {job.id}
            </h1>

            <p className="mt-4 max-w-3xl text-base leading-8 text-neutralText">
              Theo dõi tiến trình xử lý file import. Worker sẽ đọc file và ghi
              kết quả vào hệ thống.
            </p>

            <div className="mt-6 flex flex-wrap gap-3">
              <ImportJobStatusBadge status={job.status} />

              <span className="rounded-full border border-line bg-paper px-4 py-2 text-sm font-semibold text-moss">
                {getImportTypeText(job.type)}
              </span>
            </div>
          </div>

          <div className="rounded-[28px] border border-line bg-paper p-5">
            <div className="grid gap-3">
              <div className="rounded-2xl border border-line bg-surface p-4">
                <div className="flex items-center gap-3">
                  <UserRound className="h-5 w-5 text-moss" />
                  <div>
                    <p className="text-xs font-bold uppercase tracking-[.16em] text-neutralText">
                      Người tạo
                    </p>
                    <p className="mt-1 font-semibold text-ink">
                      {getUploaderName(job)}
                    </p>
                  </div>
                </div>
              </div>

              <div className="rounded-2xl border border-line bg-surface p-4">
                <p className="text-xs font-bold uppercase tracking-[.16em] text-neutralText">
                  Thời gian tạo
                </p>
                <p className="mt-1 font-semibold text-ink">
                  {formatDate(getCreatedDate(job))}
                </p>
              </div>

              <div className="rounded-2xl border border-line bg-surface p-4">
                <p className="text-xs font-bold uppercase tracking-[.16em] text-neutralText">
                  Bắt đầu xử lý
                </p>
                <p className="mt-1 font-semibold text-ink">
                  {formatDate(getStartedDate(job))}
                </p>
              </div>

              <div className="rounded-2xl border border-line bg-surface p-4">
                <p className="text-xs font-bold uppercase tracking-[.16em] text-neutralText">
                  Hoàn tất
                </p>
                <p className="mt-1 font-semibold text-ink">
                  {formatDate(getFinishedDate(job))}
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="grid gap-5 md:grid-cols-3">
        <Card className="rounded-[24px] border border-line bg-surface">
          <CardContent className="p-5">
            <CheckCircle2 className="h-5 w-5 text-moss" />
            <p className="mt-4 text-xs font-bold uppercase tracking-[.18em] text-neutralText">
              Thành công
            </p>
            <p className="mt-2 font-serif text-3xl font-bold text-ink">
              {readResultNumber(resultJson, [
                "successCount",
                "success_count",
                "createdCount",
                "created_count",
                "insertedCount",
                "inserted_count",
              ])}
            </p>
          </CardContent>
        </Card>

        <Card className="rounded-[24px] border border-line bg-surface">
          <CardContent className="p-5">
            <XCircle className="h-5 w-5 text-moss" />
            <p className="mt-4 text-xs font-bold uppercase tracking-[.18em] text-neutralText">
              Lỗi
            </p>
            <p className="mt-2 font-serif text-3xl font-bold text-ink">
              {readResultNumber(resultJson, [
                "failedCount",
                "failed_count",
                "errorCount",
                "error_count",
              ])}
            </p>
          </CardContent>
        </Card>

        <Card className="rounded-[24px] border border-line bg-surface">
          <CardContent className="p-5">
            <FileSpreadsheet className="h-5 w-5 text-moss" />
            <p className="mt-4 text-xs font-bold uppercase tracking-[.18em] text-neutralText">
              File import
            </p>
            {fileUrl ? (
              <a
                href={fileUrl}
                target="_blank"
                rel="noreferrer"
                className="mt-2 inline-flex max-w-full items-center gap-2 truncate text-sm font-semibold text-moss underline-offset-4 hover:underline"
              >
                Mở file nguồn
                <ExternalLink className="h-4 w-4" />
              </a>
            ) : (
              <p className="mt-2 text-sm text-neutralText">Chưa có file URL</p>
            )}
          </CardContent>
        </Card>
      </section>

      {errorMessage ? (
        <Card className="rounded-[28px] border border-red-200 bg-red-50">
          <CardContent className="p-5">
            <div className="flex items-start gap-3">
              <AlertTriangle className="mt-1 h-5 w-5 text-red-700" />
              <div>
                <h2 className="font-serif text-2xl font-bold text-red-800">
                  Worker báo lỗi
                </h2>
                <p className="mt-2 text-sm leading-7 text-red-700">
                  {errorMessage}
                </p>

                <Link href={`/admin/imports/${job.id}/errors`}>
                  <Button className="mt-4" variant="outline">
                    Xem chi tiết lỗi
                  </Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : null}

      <Card className="rounded-[28px] border border-line bg-surface">
        <CardHeader>
          <p className="text-xs font-bold uppercase tracking-[.22em] text-sage">
            Worker result
          </p>
          <h2 className="mt-1 font-serif text-2xl font-bold text-ink">
            Kết quả xử lý
          </h2>
          <p className="mt-1 text-sm leading-6 text-neutralText">
            Dữ liệu này được đọc từ resultJson/result_json của import job.
          </p>
        </CardHeader>

        <CardContent>
          <JsonPreview value={resultJson} />
        </CardContent>
      </Card>
    </div>
  );
}
