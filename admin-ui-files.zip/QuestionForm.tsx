import { Card } from '@/components/common/Card';
export function QuestionForm({children}:{children?:React.ReactNode}){return <Card className='p-4'><p className='font-medium'>QuestionForm</p>{children}</Card>}
