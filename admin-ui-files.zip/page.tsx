import { AdminDashboardPage } from "@/features/screens/AdminDashboardPage";

export default function Page() {
  return <AdminDashboardPage />;
}
