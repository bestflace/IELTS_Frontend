"use client";

import { ChangePasswordForm } from "@/components/profile/ChangePasswordForm";
import { PageHeader } from "@/components/common/PageHeader";

export default function AdminChangePasswordPage() {
  return (
    <div>
      <PageHeader
        eyebrow="Admin / Security"
        title="Đổi mật khẩu"
        description="Cập nhật mật khẩu đăng nhập cho tài khoản quản trị viên."
      />

      <ChangePasswordForm />
    </div>
  );
}
