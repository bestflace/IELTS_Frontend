"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import {
  Eye,
  EyeOff,
  MessageCircleReply,
  MessageSquareText,
  RefreshCw,
  Search,
  ShieldAlert,
  ExternalLink,
} from "lucide-react";

import { Button } from "@/components/common/Button";
import { Card, CardContent, CardHeader } from "@/components/common/Card";
import { Input } from "@/components/common/Input";
import { PageHeader } from "@/components/common/PageHeader";
import {
  EmptyState,
  ErrorState,
  LoadingState,
} from "@/components/common/States";
import { CommentForm } from "@/components/comments/CommentForm";
import { getErrorMessage } from "@/lib/api/client";
import {
  createAttemptComment,
  getAdminComments,
  hideComment,
  unhideComment,
} from "@/lib/api/comments.api";

type CommentStatus = "ACTIVE" | "HIDDEN" | "DELETED" | string;

type CommentAuthor = {
  id?: string;
  fullName?: string | null;
  full_name?: string | null;
  email?: string | null;
  role?: string | null;
  avatarUrl?: string | null;
  avatar_url?: string | null;
};

type CommentRow = {
  id: string;
  content?: string | null;
  body?: string | null;
  status?: CommentStatus;
  createdAt?: string;
  created_at?: string;
  updatedAt?: string;
  updated_at?: string;
  attemptId?: string;
  attempt_id?: string;
  parentId?: string | null;
  parent_id?: string | null;
  user?: CommentAuthor | null;
  author?: CommentAuthor | null;
  attempt?: {
    id?: string;
    testId?: string;
    test_id?: string;
    test?: {
      id?: string;
      title?: string | null;
      type?: string | null;
    } | null;
    tests?: {
      id?: string;
      title?: string | null;
      type?: string | null;
    } | null;
  } | null;
  attempts?: {
    id?: string;
    test_id?: string;
    tests?: {
      id?: string;
      title?: string | null;
      type?: string | null;
    } | null;
  } | null;
};

function extractItems(response: any): CommentRow[] {
  if (Array.isArray(response)) return response;
  if (Array.isArray(response?.items)) return response.items;
  if (Array.isArray(response?.data)) return response.data;
  if (Array.isArray(response?.data?.items)) return response.data.items;
  return [];
}

function getAuthor(comment: CommentRow) {
  return comment.user || comment.author || null;
}

function getAuthorName(comment: CommentRow) {
  const user = getAuthor(comment);

  return user?.fullName || user?.full_name || user?.email || "Người dùng";
}

function getAuthorRole(comment: CommentRow) {
  const role = getAuthor(comment)?.role;

  if (role === "ADMIN") return "Quản trị viên";
  if (role === "TEACHER") return "Giáo viên";
  if (role === "USER" || role === "LEARNER") return "Học viên";

  return "Người dùng";
}

function getContent(comment: CommentRow) {
  return comment.content || comment.body || "";
}

function getAttemptId(comment: CommentRow) {
  return (
    comment.attemptId ||
    comment.attempt_id ||
    comment.attempt?.id ||
    comment.attempts?.id ||
    ""
  );
}

function getTestTitle(comment: CommentRow) {
  return (
    comment.attempt?.test?.title ||
    comment.attempt?.tests?.title ||
    comment.attempts?.tests?.title ||
    "Bài làm IELTS"
  );
}

function getStatusText(status?: string) {
  if (status === "HIDDEN") return "Đã ẩn";
  if (status === "DELETED") return "Đã xóa";
  return "Đang hiển thị";
}

function getStatusClass(status?: string) {
  if (status === "HIDDEN") {
    return "bg-amber-50 text-amber-700 border-amber-200";
  }

  if (status === "DELETED") {
    return "bg-red-50 text-red-700 border-red-200";
  }

  return "bg-primarySoft text-moss border-line";
}

function formatDate(value?: string) {
  if (!value) return "—";

  try {
    return new Intl.DateTimeFormat("vi-VN", {
      hour: "2-digit",
      minute: "2-digit",
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    }).format(new Date(value));
  } catch {
    return value;
  }
}
function getSubmissionId(comment: CommentRow) {
  return (
    (comment as any).submissionId ||
    (comment as any).submission_id ||
    (comment as any).submission?.id ||
    ""
  );
}
export default function AdminCommentsPage() {
  const [comments, setComments] = useState<CommentRow[]>([]);
  const [keyword, setKeyword] = useState("");
  const [status, setStatus] = useState("");
  const [loading, setLoading] = useState(true);
  const [actionLoadingId, setActionLoadingId] = useState("");
  const [replyingId, setReplyingId] = useState("");
  const [replyLoadingId, setReplyLoadingId] = useState("");
  const [error, setError] = useState("");

  const loadData = useCallback(async () => {
    setLoading(true);
    setError("");

    try {
      const response = await getAdminComments({
        limit: 100,
        status: status || undefined,
        search: keyword.trim() || undefined,
      });

      setComments(extractItems(response));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [keyword, status]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const filteredComments = useMemo(() => {
    const normalized = keyword.trim().toLowerCase();

    return comments.filter((comment) => {
      const matchesKeyword = normalized
        ? `${getAuthorName(comment)} ${getContent(comment)} ${getAttemptId(comment)} ${getTestTitle(comment)}`
            .toLowerCase()
            .includes(normalized)
        : true;

      const matchesStatus = status ? comment.status === status : true;

      return matchesKeyword && matchesStatus;
    });
  }, [comments, keyword, status]);

  const stats = useMemo(() => {
    return {
      total: comments.length,
      active: comments.filter((item) => item.status !== "HIDDEN").length,
      hidden: comments.filter((item) => item.status === "HIDDEN").length,
    };
  }, [comments]);

  const handleHide = async (commentId: string) => {
    setActionLoadingId(commentId);
    setError("");

    try {
      await hideComment(commentId);
      await loadData();
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setActionLoadingId("");
    }
  };

  const handleUnhide = async (commentId: string) => {
    setActionLoadingId(commentId);
    setError("");

    try {
      await unhideComment(commentId);
      await loadData();
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setActionLoadingId("");
    }
  };

  const handleReply = async (comment: CommentRow, content: string) => {
    const attemptId = getAttemptId(comment);

    if (!attemptId) {
      setError("Không tìm thấy bài làm để trả lời bình luận này.");
      return;
    }

    setReplyLoadingId(comment.id);
    setError("");

    try {
      await createAttemptComment(attemptId, {
        content,
        parentId: comment.id,
      });

      setReplyingId("");
      await loadData();
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setReplyLoadingId("");
    }
  };

  if (loading) {
    return <LoadingState label="Đang tải bình luận..." />;
  }

  return (
    <div>
      <PageHeader
        eyebrow="Admin / Comments"
        title="Quản lý bình luận"
        description="Theo dõi câu hỏi, phản hồi dưới bài làm và ẩn các bình luận không phù hợp."
        actions={
          <Button variant="outline" onClick={loadData}>
            <RefreshCw className="h-4 w-4" />
            Làm mới
          </Button>
        }
      />

      {error ? <ErrorState message={error} onRetry={loadData} /> : null}

      <div className="mb-5 grid gap-4 md:grid-cols-3">
        <Card className="rounded-[22px] border border-line bg-surface">
          <CardContent className="p-5">
            <MessageSquareText className="h-5 w-5 text-moss" />
            <p className="mt-4 text-xs font-bold uppercase tracking-[.18em] text-neutralText">
              Tổng bình luận
            </p>
            <p className="mt-2 font-serif text-3xl font-bold text-ink">
              {stats.total}
            </p>
          </CardContent>
        </Card>

        <Card className="rounded-[22px] border border-line bg-surface">
          <CardContent className="p-5">
            <Eye className="h-5 w-5 text-moss" />
            <p className="mt-4 text-xs font-bold uppercase tracking-[.18em] text-neutralText">
              Đang hiển thị
            </p>
            <p className="mt-2 font-serif text-3xl font-bold text-ink">
              {stats.active}
            </p>
          </CardContent>
        </Card>

        <Card className="rounded-[22px] border border-line bg-surface">
          <CardContent className="p-5">
            <ShieldAlert className="h-5 w-5 text-moss" />
            <p className="mt-4 text-xs font-bold uppercase tracking-[.18em] text-neutralText">
              Đã ẩn
            </p>
            <p className="mt-2 font-serif text-3xl font-bold text-ink">
              {stats.hidden}
            </p>
          </CardContent>
        </Card>
      </div>

      <Card className="rounded-[28px] border border-line bg-surface">
        <CardHeader>
          <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <p className="text-xs font-bold uppercase tracking-[.22em] text-sage">
                Comment manager
              </p>
              <h2 className="mt-1 font-serif text-2xl font-bold text-ink">
                Danh sách bình luận
              </h2>
              <p className="mt-1 text-sm leading-6 text-neutralText">
                Quản trị viên có thể trả lời, ẩn hoặc bỏ ẩn bình luận trong từng
                bài làm.
              </p>
            </div>

            <div className="grid w-full gap-3 lg:w-[660px] lg:grid-cols-[1fr_220px]">
              <div className="relative">
                <Search className="pointer-events-none absolute left-3 top-3.5 h-4 w-4 text-neutralText" />
                <Input
                  value={keyword}
                  onChange={(event) => setKeyword(event.target.value)}
                  className="pl-9"
                  placeholder="Tìm theo nội dung, người bình luận hoặc mã bài làm..."
                />
              </div>

              <select
                value={status}
                onChange={(event) => setStatus(event.target.value)}
                className="h-11 w-full rounded-xl border border-line bg-surface px-3 text-sm text-ink outline-none transition focus:border-moss focus:ring-2 focus:ring-sage/20"
              >
                <option value="">Tất cả trạng thái</option>
                <option value="ACTIVE">Đang hiển thị</option>
                <option value="HIDDEN">Đã ẩn</option>
              </select>
            </div>
          </div>
        </CardHeader>

        <CardContent>
          {filteredComments.length ? (
            <div className="space-y-3">
              {filteredComments.map((comment) => {
                const hidden = comment.status === "HIDDEN";
                const attemptId = getAttemptId(comment);
                const submissionId = getSubmissionId(comment);
                return (
                  <div
                    key={comment.id}
                    className={`rounded-2xl border border-line p-5 ${
                      hidden ? "bg-cream/60" : "bg-paper"
                    }`}
                  >
                    <div className="flex flex-col gap-4 xl:flex-row xl:items-start xl:justify-between">
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <span
                            className={`rounded-full border px-3 py-1 text-xs font-semibold ${getStatusClass(
                              comment.status,
                            )}`}
                          >
                            {getStatusText(comment.status)}
                          </span>

                          <span className="rounded-full border border-line bg-surface px-3 py-1 text-xs font-semibold text-neutralText">
                            {getAuthorRole(comment)}
                          </span>

                          <span className="text-xs text-neutralText">
                            {formatDate(
                              comment.createdAt || comment.created_at,
                            )}
                          </span>
                        </div>

                        <h3 className="mt-3 font-semibold text-ink">
                          {getAuthorName(comment)}
                        </h3>

                        <p className="mt-1 text-xs font-semibold text-moss">
                          {getTestTitle(comment)}
                        </p>

                        <p className="mt-3 whitespace-pre-wrap text-sm leading-7 text-neutralText">
                          {getContent(comment) || "Không có nội dung."}
                        </p>

                        {attemptId ? (
                          <div className="mt-4 flex flex-wrap items-center gap-3">
                            <span className="rounded-xl border border-line bg-surface px-3 py-2 text-xs font-semibold text-neutralText">
                              Attempt: {attemptId}
                            </span>

                            {submissionId ? (
                              <Link href={`/admin/submissions/${submissionId}`}>
                                <Button size="sm" variant="ghost">
                                  <ExternalLink className="h-4 w-4" />
                                  Mở bài làm
                                </Button>
                              </Link>
                            ) : null}
                          </div>
                        ) : null}

                        {replyingId === comment.id ? (
                          <div className="mt-4 rounded-2xl border border-line bg-surface p-4">
                            <CommentForm
                              loading={replyLoadingId === comment.id}
                              submitLabel="Gửi phản hồi"
                              placeholder="Nhập phản hồi của quản trị viên..."
                              onSubmit={(content) =>
                                handleReply(comment, content)
                              }
                            />
                          </div>
                        ) : null}
                      </div>

                      <div className="flex shrink-0 flex-wrap gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() =>
                            setReplyingId((current) =>
                              current === comment.id ? "" : comment.id,
                            )
                          }
                        >
                          <MessageCircleReply className="h-4 w-4" />
                          Trả lời
                        </Button>

                        {hidden ? (
                          <Button
                            size="sm"
                            variant="outline"
                            disabled={actionLoadingId === comment.id}
                            onClick={() => handleUnhide(comment.id)}
                          >
                            <Eye className="h-4 w-4" />
                            Bỏ ẩn
                          </Button>
                        ) : (
                          <Button
                            size="sm"
                            variant="outline"
                            disabled={actionLoadingId === comment.id}
                            onClick={() => handleHide(comment.id)}
                          >
                            <EyeOff className="h-4 w-4" />
                            Ẩn
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <EmptyState
              title="Chưa có bình luận phù hợp"
              description="Không tìm thấy bình luận nào theo bộ lọc hiện tại."
            />
          )}
        </CardContent>
      </Card>
    </div>
  );
}
