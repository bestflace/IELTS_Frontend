"use client";

import { UserTable } from "@/components/users/UserTable";
import { PageHeader } from "@/components/common/PageHeader";

export default function AdminUsersPage() {
  return (
    <div>
      <PageHeader
        eyebrow="Admin / Users"
        title="Quản lý người dùng"
        description="Quản lý tài khoản học viên, giáo viên và quản trị viên trong hệ thống IELTSBF."
      />

      <UserTable />
    </div>
  );
}
