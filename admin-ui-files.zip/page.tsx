"use client";

import { EditProfileForm } from "@/components/profile/EditProfileForm";
import { PageHeader } from "@/components/common/PageHeader";

export default function AdminProfilePage() {
  return (
    <div>
      <PageHeader
        eyebrow="Admin / Profile"
        title="Hồ sơ quản trị viên"
        description="Quản lý thông tin cá nhân và ảnh đại diện của tài khoản đang đăng nhập."
      />

      <EditProfileForm />
    </div>
  );
}
