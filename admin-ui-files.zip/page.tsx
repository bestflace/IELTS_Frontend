"use client";

import { PageHeader } from "@/components/common/PageHeader";
import { NotificationList } from "@/components/notifications/NotificationList";

export default function AdminNotificationsPage() {
  return (
    <div>
      <PageHeader
        eyebrow="Admin / Notifications"
        title="Thông báo hệ thống"
        description="Theo dõi các cập nhật quan trọng, bình luận và hoạt động trong hệ thống."
      />

      <NotificationList />
    </div>
  );
}
